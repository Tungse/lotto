/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function(b,c){var $=b.jQuery||b.Cowboy||(b.Cowboy={}),a;$.throttle=a=function(e,f,j,i){var h,d=0;if(typeof f!=="boolean"){i=j;j=f;f=c}function g(){var o=this,m=+new Date()-d,n=arguments;function l(){d=+new Date();j.apply(o,n)}function k(){h=c}if(i&&!h){l()}h&&clearTimeout(h);if(i===c&&m>e){l()}else{if(f!==true){h=setTimeout(i?k:l,i===c?e-m:e)}}}if($.guid){g.guid=j.guid=j.guid||$.guid++}return g};$.debounce=function(d,e,f){return f===c?a(d,e,false):a(d,f,e!==false)}})(this);


/*
 * jQuery "splendid textchange" plugin
 * http://benalpert.com/2013/06/18/a-near-perfect-oninput-shim-for-ie-8-and-9.html
 *
 * (c) 2013 Ben Alpert, released under the MIT license
 */
 (function(e){var t=document.createElement("input");var n="oninput"in t&&(!("documentMode"in document)||document.documentMode>9);var r=function(e){return e.nodeName==="INPUT"&&(e.type==="text"||e.type==="password")};var i=null;var s=null;var o=null;var u={get:function(){return o.get.call(this)},set:function(e){s=e;o.set.call(this,e)}};var a=function(e){i=e;s=e.value;o=Object.getOwnPropertyDescriptor(e.constructor.prototype,"value");Object.defineProperty(i,"value",u);i.attachEvent("onpropertychange",l)};var f=function(){if(!i)return;delete i.value;i.detachEvent("onpropertychange",l);i=null;s=null;o=null};var l=function(t){if(t.propertyName!=="value")return;var n=t.srcElement.value;if(n===s)return;s=n;e(i).trigger("textchange")};if(n){e(document).on("input",function(t){if(t.target.nodeName!=="TEXTAREA"){e(t.target).trigger("textchange")}})}else{e(document).on("focusin",function(e){if(r(e.target)){f();a(e.target)}}).on("focusout",function(){f()}).on("selectionchange keyup keydown",function(){if(i&&i.value!==s){s=i.value;e(i).trigger("textchange")}})}})(jQuery)


/*!
 * Webguerillas Form Plugin
 * Author: Funda Yanc
 * Credits to Robin Schmitz
 * Version: 0.1 alpha
 * Date 16.01.2014
 */

/*!
 * jQuery lightweight plugin boilerplate
 * Original author: @ajpiano
 * Further changes, comments: @addyosmani
 * Licensed under the MIT license
 * https://github.com/jquery-boilerplate/jquery-patterns/
 */

/*
 * the semi-colon before the function invocation is a safety
 * net against concatenated scripts and/or other plugins
 * that are not closed properly.
 */
;(function ( $, window, document, undefined ) {
    "use strict";

    var counter = 0;
    /*
     * undefined is used here as the undefined global
     * variable in ECMAScript 3 and is mutable (i.e. it can
     * be changed by someone else). undefined isn't really
     * being passed in so we can ensure that its value is
     * truly undefined. In ES5, undefined can no longer be
     * modified.
     */

    /*
     * window and document are passed through as local
     * variables rather than as globals, because this (slightly)
     * quickens the resolution process and can be more
     * efficiently minified (especially when both are
     * regularly referenced in your plugin).
     */

    /* Create the defaults once. To change the default values, set them in form.html at the bottom in the script part. */
    var pluginName = "wgForm",
        defaults = {
            /* propertyName: "value", */ 
            invalid: {
                /* The postal code entered is not valid. */
                fatalZip: {
                    status: 'no matching zip',
                    message: 'No matching postal code could be found. Please review your postal code.',
                    displayEl: '#postalerrors',
                    cssClass: 'error',
                    callback: 'onFatalZip'
                },
                /* The email syntax is invalid. */
                emailInvalid: {
                    status: 'invalid email',
                    message: 'Please enter an email address with valid syntax (example: "nick@domain.com").',
                    displayEl: '#mailerrors',
                    cssClass: 'error',
                    callback: 'onInvalidMail'
                },
                /*before performing a submit action, check all possible errors (e.g. syntax error in the email field, empty mandatory field)*/
                commonError: {
                    status: 'common error',
                    displayEl: '#form-validation-messages',
                    message: 'Please review the fields marked red.',
                    cssClass: 'error',
                    callback: 'onCommonErrorOccurred'
                }
            },
            valid: {
                /* The entered postal code is valid. Here you could mark the field green for correct if you wanted. */
                validZip: {
                    status: 'matching zip',
                    message: '',
                    displayEl: '#postalerrors',
                    cssClass: 'correct',
                    callback: 'onValidZip'
                },
                /* The email address is valid. */
                emailValid: {
                    status: 'valid email',
                    message: '',
                    displayEl: '#mailerrors',
                    cssClass: 'correct',
                    callback: 'onValidMail'
                },
                /* No invalid field could be fonud. */
                commonError: {
                    status: 'common status ok',
                    displayEl: '#form-validation-messages',
                    message: '+OK+',
                    cssClass: 'correct',
                    callback: 'onCommonErrorSolved'
                }
            },
            hint: {
                /* This case can be completely ignored for Germany. In some countries multiple Places match one postal code.*/
                multiplePlaces: {
                    status: 'multiple places found',
                    message: 'More than one place matches your postal code. Please choose one.',
                    displayEl: '#postalerrors',
                    cssClass: 'error',
                    callback: 'onMultiplePlaces'
                },
                /* This case can be completely ignored for Germany. If multiple places match one postal code and the user chooses one place of the provided suggestions. */
                selectedPlace: {
                    status: 'place selected',
                    message: ' ',
                    displayEl: '#postalerrors',
                    cssClass: 'correct',
                    callback: 'onPlaceSelected'
                }
            },
            error: {
                /* The web service is currently not available. */
                geoService: {
                    status: 'service not available',
                    message: 'The web service is currently not available. Please try again later.',
                    displayEl: '#webserviceErrors',
                    cssClass: 'error',
                    callback: 'onGeoAPIunavailable'
                }
            },
            debug: false
        };

    /* The actual plugin constructor */
    function Plugin( element, options, instanceNo ) {
        this.element = element;
        this.instanceNo = instanceNo;
        this.$element = $(element);
        /*
         * jQuery has an extend method that merges the
         * contents of two or more objects, storing the
         * result in the first object. The first object
         * is generally empty because we don't want to alter
         * the default options for future instances of the plugin
         */

        this.options = $.extend( {}, defaults, options) ;

        this._defaults = defaults;
        this._name = pluginName;
        this.init();
    }

    /* object of class Plugin */
    Plugin.prototype = {

        init: function() {
            /* 
             * Place initialization logic here
             * You already have access to the DOM element and
             * the options via the instance, e.g. this.element
             * and this.options
             * you can add more functions like the one below and
             * call them like so: this.yourOtherFunction(this.element, this.options).
             */

            if (this.debug) console.log("init");

            /* initialize debounced function */
            this.debouncedPostalCodeLookup = $.debounce(250, this.postalCodeLookup);

            /* chache jquery objects once and save it in a variable and prevent performance issues */
            this.$form = this.$element.parents('form:first');

            /* prevent default validation */
            this.$form.attr("novalidate", "");

            /* to make sure only plugin event listener will be removed, a namespace is used */
            this.$form.on("submit.wgformplugin"+this.instanceNo, $.proxy(this.onSubmit, this));

            this.$inputElement = this.$element;
            this.initInput();          

            /* if the dev has added custom code to the plugin, execute it here */
            if  ('onInit' in this.options) {
                this.options['onInit']();
            }
        },

        /* 
         * Initialising type of input element.
         * Note: IE8/IE9 don't support input types like email, tel, search etc., they interpret these elements as text input types.
         */
        initInput: function() {
            this.options.type = this.$element.prop("type");
            var inputType = this.options.type;

            this.options.pattern = this.$element.attr("pattern");
            var inputPattern = this.options.pattern;

            this.$element.on("change.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this));

                 if (inputType === "select-one")    { this.$element.on("change.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this)); this.setDefaultCountry(); }
            else if (inputType === "checkbox")      { this.$element.on("change.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this)); }
            else if (inputType === "button")        { /*this.$element.on('click', $.proxy(this.onButtonClicked, this));*/ }
            else if (inputType === "submit")        { /*this.$element.on('click', $.proxy(this.onButtonClicked, this));*/ }
            else if (inputType === "reset")         { /*this.$element.on('click', $.proxy(this.onButtonClicked, this));*/ }
            else if (inputType === "radio")         { this.$element.on("change.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this)); }
            else if (inputType === "textarea")      { this.$element.on("change.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this)); }
            else {
                // IE8 and IE9 don't know the input type email. That's why an data attribute has been used.
                if (this.$element.attr("data-wg") === "email") {
                    this.options.type = "email";
                    inputType = this.options.type;
                    this.$element.on("onblur.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this));
                }
                else if (this.$element.attr("data-wg") === "datepicker") {
                    this.options.type = "datepicker";
                    inputType = this.options.type;
                    this.$element.on("onblur.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this));
                }
                else {
                    this.options.type = "text";
                    inputType = this.options.type;

                    if(this.$element.attr("maxLength") !== undefined) {
                        this.options.maxLength = parseInt(this.$element.attr("maxLength"));
                    }
                    this.$element.on("textchange.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this));
                }
                /*
                 * https://github.com/spicyj/jquery-splendid-textchange
                 * This plugin provides a synthetic event called textchange which 
                 * simulates the input event in all browsers, abstracting over cross-browser differences.
                 *  Supports IE 8, IE 9, and modern browsers.
                 ‚*/
                if (this.$element.attr("data-wg") === "postalcode") {
                    this.$element.autocomplete({
                        source: [],
                        select: function( event, ui ) {}
                    });
                    this.$element.on("textchange.wgformplugin"+this.instanceNo, $.proxy(this.onInput, this));
                }

            }

            if (this.debug)
            {
                console.log("inputType: ", inputType);
                console.log("inputPattern: ", inputPattern);
                console.log("maxLength: ", this.options.maxLength);
            }
        },

        onInput: function() {
            if (this.debug) console.log("ON INPUT");
            this.validate();
        },

        onChanged: function() {
            if (this.debug) console.log("ON CHANGED");
        },

        onSubmit: function(e) {
            if (this.debug) console.log("ON SUBMIT CLICKED");
            this.$element.removeClass(this.options.invalid.commonError.cssClass);
            if (this.options.type === "checkbox" || this.options.type === "radio") {
                $("label[for='"+this.element.id+"']").removeClass(this.options.invalid.commonError.cssClass);
            }
            var validField = this.validate();

            if (!('wgFormFirst' in e)) {
                e.wgFormFirst = true;
                if (this.debug) console.error('1st');
                if (typeof this.options.valid.commonError.callback == 'function') {
                    this.options.valid.commonError.callback.call(this);
                }
                else {
                    this[this.options.valid.commonError.callback]();
                }
            }else {
                if (this.debug) console.warn('not 1st');
            }

            if (!validField && !e.isDefaultPrevented()) {
                /* First time invalid */
                if (this.debug) console.error('Canceling form submit');
                /* Preventing Form Submit */
                e.preventDefault();
                /* 
                 * Outputting global error message once.
                 * If the dev has added custom callback function to the plugin, execute it. If not, execute the callback provided in options. 
                 */
                 console.log("type: ", typeof(this.options.invalid.commonError.callback), "function: ", this.options.invalid.commonError.callback);
                //if  (this.options.invalid.commonError.customCallback in this.options && typeof(this.options.invalid.commonError.customCallback)==="function") { /* seeking custom callback function */
                if (typeof this.options.invalid.commonError.callback == 'function') {
                    //this.options[this.options.invalid.commonError.callback]();
                    // this.options.invalid.commonError.callback(); //evtl. apply oder call; input el als parameter mitgeben
                    this.options.invalid.commonError.callback.call(this); //evtl. apply oder call; input el als parameter mitgeben
                }
                else {
                    this[this.options.invalid.commonError.callback]();
                    //this.options.invalid.commonError.callback(this);
                }
            }else if (!validField) {
                /* All other invalid submits */
                if (this.debug) alert('ERROR');
                if (this.debug) console.warn('Form submit is already cancelled');
            }

            if (!validField) {
                /* All invalids */               
                this.$element.addClass(this.options.invalid.commonError.cssClass); // color of input field
                if (this.options.type === "checkbox" || this.options.type === "radio") {
                    $("label[for='"+this.element.id+"']").addClass(this.options.invalid.commonError.cssClass);
                }
            }
        },

        /*
         * this function will be called after the JSON request
         * the parameter suggestions contains Cities matching the postalcode
         */
        getLocation: function(suggestions) {
            if (this.debug) console.log("getLocation: ", suggestions);
            if (suggestions === null) {
                /* There was a problem parsing search results */
                if (this.debug) console.log("An error occured. Please try again later.");
                this[this.options.error.geoService.callback]();
                return;
            }

            if (this.debug) console.log("suggestions:", suggestions.length);

            if (suggestions.length === 0) {
                if (this.debug) console.log("No matching place with your postal code. Please review your postal code.");
                this[this.options.invalid.fatalZip.callback]();
            }
            if (suggestions.length > 1) {
                /* we got multiple places for the postalcode */
                this.$element.on( "autocompleteselect.wgformplugin"+this.instanceNo, $.proxy(function( event, ui ) {
                    $('[data-wg="place"]').val(suggestions[ui.item.index].placeName); //evtl target verknüpfen von plz und ort
                    this[this.options.hint.selectedPlace.callback]();
                    if (this.debug) console.log("SELECTION PERFORMED");
                } , this));
                //if (this.debug) console.log("More than 1 place matches with your postal code. Please choose one.");
                this[this.options.hint.multiplePlaces.callback]();

            } else {
                if (suggestions.length == 1) {
                    // exactly one place for postalcode
                    this.$element.autocomplete( "disable" );
                    this.$element.val(suggestions[0].value);
                    $('[data-wg="place"]').val(suggestions[0].placeName);
                    if (this.debug) console.log("There is exact one match with your postal code.");
                    this[this.options.valid.validZip.callback]();
                }
            }
        },

        updateAutocomplete: function(suggestions) {
            if (this.debug) console.log("AUTOCOMPLETE UPDATE");
            if (this.debug) console.log("updateAutocomplete");
            if (this.debug) console.log(suggestions, this);

            //attach autocomplete 
            // see http://api.jqueryui.com/autocomplete/#method-option
            this.$element.autocomplete('option', 'source', suggestions);
            this.getLocation(suggestions);
        },

        // this function is debounced 
        // webservice example: http://www.geonames.org/export/ajax-postalcode-autocomplete.html
        postalCodeLookup: function() {
            if (this.debug) console.log("postalCodeLookup");
            var country = document.getElementById("countrySelect").value;

            if (geonamesPostalCodeCountries.toString().search(country) == -1) {
                return; // selected country not supported by geonames
            }

            var postalcode = document.getElementById("postalcodeInput").value;
            var request = 'http://api.geonames.org/postalCodeLookupJSON?postalcode=' + postalcode  + '&country=' + country  + '&username=funda&callback=?';
            //if (this.debug) console.log(request);

            //create array for response objects  
            var suggestions = [];

            $.getJSON(request, $.proxy(function(data) {                             
                        //process response  
                        $.each(data.postalcodes, function(i, val){                       
                            suggestions.push({label: val.placeName+' '+val.postalcode, value: val.postalcode, index: i, placeName: val.placeName}); 
                        });
                        //if (this.debug) console.loginfo(data, suggestions, this);
                        this.updateAutocomplete(suggestions);
            }, this));
        },

        // set the country of the user's ip (included in geonamesData.js) as selected country 
        // in the country select box of the address form
        setDefaultCountry: function() {
            if (this.debug) console.log("setDefaultCountry");

            if (this.$element.attr("data-wg") && this.$element.attr("data-wg") === "country") {
                var countrySelect = this.element; //document.getElementById("countrySelect");
                for (var i=0;i< countrySelect.length;i++) {
                    // the javascript geonamesData.js contains the countrycode
                    // of the userIp in the variable 'geonamesUserIpCountryCode'
                    if (countrySelect[i].value == geonamesUserIpCountryCode) {
                      // set the country selectionfield
                      countrySelect.selectedIndex = i;
                    }
                }
            }

        },

        isEmail: function(value) {
            if (this.options.pattern) {
                var regex = new RegExp(this.options.pattern);
                return regex.test(value);
            }
            return false;
        },

        checkPattern: function() {
            console.log("check pattern");
            var val = this.options.value;
            var allowed = true;
            var p = new RegExp(this.options.pattern);

            for(var i=0;i<val.length;i++){
                allowed = false;
                if(p.test(val.charAt(i))) { allowed = true; }
                if(allowed === false){ val = val.replace(val.charAt(i),""); this.options.value = this.element.value = val; i--; }
            }
        },

        checkLength: function() {
            var maxLength = this.options.maxLength;
            var currLength = this.options.currLength = this.element.value.length;

            if (currLength > maxLength) this.element.value = this.element.value.substring(0, maxLength);
            //only if the length of the postalcode is correct, call the debounced function and perform a getJSON request
            else if (currLength === maxLength && this.$element.attr("data-wg") === "postalcode") {
                this.debouncedPostalCodeLookup();
            }
        },

        inputTypeEmailSupported: function() {
            var i = document.createElement("input");
            if (this.debug) console.warn(i);
            i.setAttribute("type", "email");
            var test = $(i).attr('type');
            if (i.type !== "email") return false;
            else return true;
        },

        isRequired: function(el) {
            if (this.debug) console.log("IS REQUIRED");
            var $el = $(el);

            if ($el.attr('required')) {
                    return true;
            } else {
                return false;
            }
        },

        onFatalZip: function() {
            this.displayValidation(this.options.invalid.fatalZip);
            this.$element.removeClass(this.options.valid.validZip.cssClass);
        },

        onValidZip: function() {
            this.displayValidation(this.options.valid.validZip);
            this.$element.removeClass(this.options.invalid.fatalZip.cssClass);
        },

        onInvalidMail: function() {
            this.displayValidation(this.options.invalid.emailInvalid);
            this.$element.removeClass(this.options.valid.emailValid.cssClass);
        },

        onValidMail: function() {
            this.displayValidation(this.options.valid.emailValid);
            this.$element.removeClass(this.options.invalid.emailInvalid.cssClass);
        },

        onMultiplePlaces: function() {
            this.displayValidation(this.options.hint.multiplePlaces);
            this.$element.removeClass(this.options.hint.selectedPlace.cssClass);
        },

        onPlaceSelected: function() {
            this.displayValidation(this.options.hint.selectedPlace);
            this.$element.removeClass(this.options.hint.multiplePlaces.cssClass);
        },

        onGeoAPIunavailable: function() {
            this.displayValidation(this.options.error.geoService);
        },

        onCommonErrorOccurred: function() {
            $(this.options.invalid.commonError.displayEl)
            .html(this.options.invalid.commonError.message)
            .addClass(this.options.invalid.commonError.cssClass) // color of the displayEl
            .removeClass(this.options.valid.commonError.cssClass);
        },

        onCommonErrorSolved: function() {
            $(this.options.invalid.commonError.displayEl)
            .html(this.options.valid.commonError.message)
            .addClass(this.options.valid.commonError.cssClass)
            .removeClass(this.options.invalid.commonError.cssClass);
        },

        displayValidation: function(el) {
            this.$element.addClass(el.cssClass);
            if(el.displayEl !== '' && el.displayEl !== undefined && el.displayEl !== null
                                   && el.message !== undefined && el.message !== null) {
                $(el.displayEl).text(el.message);
            }
        },

        validate: function() {
            if (this.debug) console.log("validate");
            if(this.validateRequired() === false) return false;

            //http://api.jquery.com/jQuery.trim/
            this.element.value = $.trim(this.element.value);
            this.options.value = this.element.value;

            if (this.options.type === "email") {
                if(this.isEmail(this.options.value)) {
                    if (this.debug) console.log("correct email");
                    this.onValidMail();
                }
                else {
                    if (this.debug) console.log("email not correct");
                    //this.$element.addClass("error");
                    this.onInvalidMail();
                    return false;
                }
            }
            else if (this.options.type === "datepicker") {
                return this.isValidDate(this.$element.val());
            }
            else if (this.$element.attr("pattern") != undefined && this.options.type !== "datepicker") {
                this.checkPattern();
            }

            if (this.$element.attr("maxLength") != undefined) {
                this.checkLength();
            }
            return true;
        },

        validateRequired: function() {
            // if this is not a required field, set validation to true
            if (this.isRequired(this.element) === false) return true;
            if (this.options.type === "button" || this.options.type === "submit" || this.options.type === "reset") return true;

            if(this.options.type === "radio") {
                var checked = false; 
                var input = $("input:radio[name="+$(this.element).attr('name')+"]");
                input.each(function(i, val) {
                    //console.log(i, val);
                    if (val.checked) {
                        console.log("checked");
                        checked = true;
                    }
                    else {
                        console.log("unchecked");
                    }
                });
                return checked;
            }
            else if (this.options.type === "checkbox") {
                return this.$element.is(':checked');
            }

            else {
                if(this.$element.val() === '') {
                    return false;
                }
                else {
                    return true;
                }
            }
            
        },

        isValidDate: function(s) {
          var bits = s.split('.');
          var d = new Date(bits[2], bits[1] - 1, bits[0]);
          return d && (d.getMonth() + 1) == bits[1] && d.getDate() == Number(bits[0]);
        },

        /* 
         * If the plugin is no more needed, its instance should be destroyed for performance reasons.
         * All eventlisteners and attributes set by the plugin should be deleted 
         * without touching the HTML elements itself. The dev can also add his own event 
         * listeners via js outside the plugincode, they will be not affected by executing this function. 
         */
        destroy: function() {
            console.log(this.instanceNo,this.$element);
            if (this.debug) console.log("destroy");

            // to make sure only plugin event listener will be removed, a namespace is used
            //this.$element.off(".wgformplugin"+this.instanceNo+this.element.id);
            this.$element.off(".wgformplugin"+this.instanceNo);

            this.$form.off("submit.wgformplugin"+this.instanceNo);

            //this.$form.removeAttr("novalidate");
            //this._destroy(); //or this.delete; depends on jQuery version
        }

    };

    // A really lightweight plugin wrapper around the constructor,
    // preventing against multiple instantiations
    // this.each will run only once for $(document)
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, "plugin_" + pluginName)) {
                // console.log(counter);
                counter++;
                $.data(this, "plugin_" + pluginName,
                new Plugin( this, options, counter ));
            }
        });
    };

})( jQuery, window, document );